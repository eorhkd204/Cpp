#include <iostream>
using namespace std;

#include "Shape.h"

void Shape::paint() {
	draw();
}