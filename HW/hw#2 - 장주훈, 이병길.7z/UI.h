#pragma once
#include <string>

class UI {
public:
	static int getMenu();
	static int getShapeMenu();
	static int getShapedelete();
	static void printIn(string);
	static void print(string);
	static void print(int);
};