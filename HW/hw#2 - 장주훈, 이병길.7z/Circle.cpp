#include <iostream>
using namespace std;
#include "Shape.h"
#include "Circle.h"

void Circle::draw() {
	cout << "Circle" << endl;
}